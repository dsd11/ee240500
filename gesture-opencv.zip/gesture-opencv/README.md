gesture-opencv
==============

This python script can be used to analyse hand gestures by contour detection,
and convex hull of hand palm using opencv library used for computer vision
processes.

* Built using OpenCV 2.4.12 on Python 2.7.10
* Works on OpenCV 2.4.x and Python 2.x

Video
=====

link: [http://goo.gl/fui2MH ](http://goo.gl/fui2MH)

[![IMAGE ALT TEXT](https://img.youtube.com/vi/QYiypuWZPU0/0.jpg)](https://www.youtube.com/watch?v=QYiypuWZPU0)

See Also
========
Playing Pacman with gestures: [Repository](http://github.com/vipul-sharma20/gesture-pacman)
